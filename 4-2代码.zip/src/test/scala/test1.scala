import java.text.SimpleDateFormat
import java.util.Date

object test1 {
  def main(args: Array[String]): Unit = {
    val date = new Date();
    val sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
  }
}
